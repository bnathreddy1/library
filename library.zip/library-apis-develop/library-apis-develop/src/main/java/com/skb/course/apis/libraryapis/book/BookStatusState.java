package com.skb.course.apis.libraryapis.book;

public enum BookStatusState {

    Active,
    Inactive;
}
