package com.skb.course.apis.libraryapis.model.common;

public enum Gender {

    Male,
    Female,
    Undisclosed;
}
